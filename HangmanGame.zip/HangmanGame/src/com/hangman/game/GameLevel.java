package com.hangman.game;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public enum GameLevel {

	ESAY("easy"), MEDIUM("medium"), HARD("hard");

	private String level;

	private GameLevel(String level) {

		this.level = level;
	}

	public String getLevel() {

		return level;
	}

	public static GameLevel getRandam() {

		GameLevel[] levels = { GameLevel.ESAY, GameLevel.MEDIUM, GameLevel.HARD };

		return levels[(int) (Math.random() * levels.length)];
	}

}
