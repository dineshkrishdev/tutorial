package com.hangman.game;

import java.util.Scanner;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class Game {

	static String wordGuessed = "";

	public static void main(String[] args) {

		HangmanGame game = null;

		Scanner sc = new Scanner(System.in);

		System.out.println("Welcome to Hangman Game");

		System.out.println("Select the level : {Easy, Medium, Hard, Random} and type to 'exit' to quit game !!!");

		String level = sc.next();

		if (level.equalsIgnoreCase(GameLevel.ESAY.getLevel())) { // setting the level from the user selection

			game = new HangmanGame(GameLevel.ESAY);
		} else if (level.equalsIgnoreCase(GameLevel.MEDIUM.getLevel())) {

			game = new HangmanGame(GameLevel.MEDIUM);
		} else if (level.equalsIgnoreCase(GameLevel.HARD.getLevel())) {

			game = new HangmanGame(GameLevel.HARD);
		} else {

			game = new HangmanGame(GameLevel.getRandam()); // random level 
		}

		System.out.println(game.getGameWord());

		while (game.getCount() < 5 && true) { // running loop until the count is < 5

			String guess = sc.next();

			if (guess.equalsIgnoreCase("exit")) {

				System.out.println("Game exited");
				System.exit(0);
			}

			game.hang(guess);

			wordGuessed += guess.charAt(0); // this is for guessed string

			System.out.println(
					game.getGameWord() + ", so far " + wordGuessed + " - and number of life " + (5 - game.getCount()));
		}

		if (game.getCount() >= 5) {

			System.out.println("Game over");
			sc.close();
			System.exit(0);
		}

	}

}
