package com.hangman.game;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class HangmanGame {

	public static String[] easyList = { "one", "two" };
	public static String[] mediumList = { "cow", "orange" };
	public static String[] hardList = { "computer", "printer" };

	private static int count = 0;

	public static String word;

	public static String gameWord;

	/*
	 * Constructor which accept the game level
	 */
	public HangmanGame(GameLevel level) {

		if (level.getLevel().equals("easy")) {

			word = easyList[(int) Math.random() * easyList.length];

		} else if (level.getLevel().equals("medium")) {

			word = mediumList[(int) Math.random() * mediumList.length];

		} else if (level.getLevel().equals("hard")) {

			word = hardList[(int) Math.random() * hardList.length];

		}

		gameWord = new String(new char[word.length()]).replace("\0", "-");

	}

	/**
	 * The main logic of the game
	 * 
	 * @param guess
	 */
	public void hang(String guess) {

		guess = guess.toLowerCase(); // converting to lower case to support case
										// sensitive
		String newGameWord = "";

		for (int i = 0; i < word.length(); i++) {
			if (word.charAt(i) == guess.charAt(0)) {
				newGameWord += guess.charAt(0);
			} else if (gameWord.charAt(i) != '-') {
				newGameWord += word.charAt(i);
			} else {
				newGameWord += "-";
			}
		}

		if (gameWord.equals(newGameWord)) { // if the game word and new word are
											// eq increasing the count
			count++;
			System.out.println("wrong guess");
		} else {
			gameWord = newGameWord;
		}

		if (gameWord.equals(word)) { // once found correct answer
			System.out.println(word);
			System.out.println("Correct answer..");
			System.exit(0);
		}

	}

	public int getCount() {

		return count;
	}

	public String getGameWord() {

		return gameWord;
	}

}
