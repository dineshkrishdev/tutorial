package com.dineshkrish.soap;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

@WebService(endpointInterface = "com.dineshkrish.soap.AuthenticationService")
@SOAPBinding(style = Style.RPC)
public class AuthenticationServiceImpl implements AuthenticationService {

	@Override
	public boolean authenticate(String userName, String password) {
		
		
		if(userName != null && password != null) {
			
			if(userName.equals("admin") && password.equals("password")) {
				
				return true;
			}
			
		}
		
		return false;
	}

}
