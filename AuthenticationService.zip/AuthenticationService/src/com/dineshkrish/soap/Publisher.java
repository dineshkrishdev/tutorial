package com.dineshkrish.soap;

import javax.xml.ws.Endpoint;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class Publisher {

	public static void main(String[] args) {
		
		final String serviceURL = "http://localhost:8080/auth";
		
		Endpoint endpoint = Endpoint.publish(serviceURL, new AuthenticationServiceImpl());
		
		if(endpoint.isPublished()) {
			
			System.out.println("Authentication service is running at "+serviceURL);
		} else {
			
			System.out.println("Service Error");
		}
		
	}
	
}
