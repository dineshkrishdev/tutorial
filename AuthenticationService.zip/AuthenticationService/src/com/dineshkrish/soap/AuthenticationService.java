package com.dineshkrish.soap;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

@WebService
@SOAPBinding(style = Style.RPC)
public interface AuthenticationService {
	
	public boolean authenticate(String userName, String password);

}
