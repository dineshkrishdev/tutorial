package com.dineshkrish.soap.client;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.dineshkrish.soap.AuthenticationService;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class LoginClient {

	public static void main(String[] args) {

		final String SERVICE_ADDRESS = "http://localhost:8080/auth?WSDL";
		final String NAMESPACE = "http://soap.dineshkrish.com/";
		final String SERVICE_NAME = "AuthenticationServiceImplService";
		
		String userName = "admin";
		String password = "password";

		try {

			URL url = new URL(SERVICE_ADDRESS);

			QName qName = new QName(NAMESPACE, SERVICE_NAME);

			Service service = Service.create(url, qName);

			AuthenticationService authService = service.getPort(AuthenticationService.class);

			boolean isValidUser = authService.authenticate(userName, password);
			
			if(isValidUser)  {
				
				System.out.println("You are logged in successfully...");
			} else {
				
				System.out.println("You are not a authorized user!");
			}

			
		} catch (Exception ex) {

			System.out.println(ex.getMessage());
		}

	}

}
