/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.shopping.dao;

import com.demo.shopping.to.ProductTO;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MRuser
 */
public class ProductListDAO {
    
    public List<ProductTO> getProducts() {
        
        
        
        List<ProductTO> productList = new ArrayList<ProductTO>(); 
     
        // i am going to talk to database
        
        
        ProductTO p1 = new ProductTO();
        p1.setProductId(101);
        p1.setProductName("Milk");
        p1.setProductPrice(10);
        p1.setProductDescription("Milk products");
        
        ProductTO p2 = new ProductTO();
        p2.setProductId(102);
        p2.setProductName("Chocolate");
        p2.setProductPrice(12);
        p2.setProductDescription("Chocolate products");
        
        ProductTO p3 = new ProductTO();
        p3.setProductId(103);
        p3.setProductName("Jam");
        p3.setProductPrice(5);
        p3.setProductDescription("Jam products");
        
        productList.add(p1);
        productList.add(p2);
        productList.add(p3);
        
        return productList;
    }
}
