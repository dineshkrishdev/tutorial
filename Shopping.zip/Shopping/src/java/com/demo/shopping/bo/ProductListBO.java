/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.shopping.bo;

import com.demo.shopping.dao.ProductListDAO;
import com.demo.shopping.to.ProductTO;
import java.util.List;

/**
 *
 * @author MRuser
 */
public class ProductListBO {
    
    public List<ProductTO> getProductList() {
        
        ProductListDAO dao = new ProductListDAO();
        
        // I am have to do the bl 
        
        return dao.getProducts();
        
    }
    
}
