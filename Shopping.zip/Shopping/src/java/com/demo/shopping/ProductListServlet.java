/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.demo.shopping;

import com.demo.shopping.bo.ProductListBO;
import com.demo.shopping.to.ProductTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author MRuser
 */

@WebServlet(name = "productList", urlPatterns = {"/getProductList"})
public class ProductListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        ProductListBO bo = new ProductListBO();
        
        List<ProductTO> productList = bo.getProductList();
        
        PrintWriter out = resp.getWriter();
        
        resp.setContentType("text/html");
        
        out.println("<h1>Product List</h1>");
        
        out.println("<table cellpadding='5' cellspacing='5' border='1'>");
        out.println("<tr>"
                + "<th>ID</th>"
                + "<th>Name</th>"
                + "<th>Description</th>"
                + "<th>Price</th>"
                + "</tr>");
        for(ProductTO p: productList) {
            
           out.println("<tr>"
                   + "<td>"+p.getProductId()+"</td>"
                   + "<td>"+p.getProductName()+"</td>"
                   + "<td>"+p.getProductDescription()+"</td>"
                   + "<td>"+p.getProductPrice()+"</td>"
                   + "</tr>");
        }
        
        out.println("</table>");
        
        out.close();;
        
        
    }
    
   
}
