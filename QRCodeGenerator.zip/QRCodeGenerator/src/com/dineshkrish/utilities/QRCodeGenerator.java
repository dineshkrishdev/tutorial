package com.dineshkrish.utilities;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;
import java.util.Scanner;

import javax.imageio.ImageIO;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class QRCodeGenerator {
	
	// You can change your path name accordingly
	private static final String PATH = "output/";
	
	private static final String FILETYPE = "png";
	
	// Image Width and Height
	private static final int IMAGE_SIZE = 250;
	
	// Method to Generate QR Code
	public static boolean generate(String text, String fileName) {
		
		if((text != null && !text.isEmpty()) && 
				(fileName != null && !fileName.isEmpty())) {
			
			// Defining the File Object with File name (eg: output/test.png)
			File file = new File(PATH + fileName + "." + FILETYPE);
			
			try {

				Map<EncodeHintType, Object> hintMap = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
				
				hintMap.put(EncodeHintType.CHARACTER_SET, "UTF-8");
				hintMap.put(EncodeHintType.MARGIN, 1);
				hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

				// Defining QRCodeWriter Object
				QRCodeWriter qrcw = new QRCodeWriter();
				
				BitMatrix bitMatrix = qrcw.encode(text, BarcodeFormat.QR_CODE, IMAGE_SIZE, IMAGE_SIZE, hintMap);
				
				int width = bitMatrix.getWidth(); // Width : 250 
				
				int height = bitMatrix.getHeight(); // Height : 250
				
				BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
				
				image.createGraphics();

				Graphics2D graphics = (Graphics2D) image.getGraphics();
				
				// Setting Background Color
				graphics.setColor(Color.WHITE);
				
				graphics.fillRect(0, 0, width, height);
				
				// Setting Content Color
				graphics.setColor(Color.RED);

				for (int i = 0; i < width; i++) {
					for (int j = 0; j < height; j++) {
						if (bitMatrix.get(i, j)) {
							graphics.fillRect(i, j, 1, 1);
						}
					}
				}
				
				return ImageIO.write(image, FILETYPE, file);

			} catch (WriterException e) {
			
				e.printStackTrace();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		} else {
		
			System.out.println("Invalid Input Found!!!");
			System.exit(0);
		}
				
		return false;
	}

	public static void main(String[] args) {

		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("What Text you want to Convert to QR Code ? ");
		
		String text = scanner.next();
		
		System.out.println("What File Name you want to keep for QR Code Image ? ");
		
		String fileName = scanner.next();
		
		boolean status = QRCodeGenerator.generate(text, fileName);
		
		if(status) {
			System.out.println("The QR Code Generated Successfully.");
		} else {
			System.out.println("Error During Generating QR Code.");
		}
		
		scanner.close();
	}
}
