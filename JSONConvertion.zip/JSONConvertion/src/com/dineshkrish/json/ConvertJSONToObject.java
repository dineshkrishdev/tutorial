package com.dineshkrish.json;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import com.google.gson.Gson;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class ConvertJSONToObject {

	public static void main(String[] args) {

		Employee employee = null;

		Gson gson = new Gson();

		File jsonFile = new File("input/data.json");

		try {

			FileReader reader = new FileReader(jsonFile);
			
			employee = gson.fromJson(reader, Employee.class);
			
			System.out.println("JSON File Converted to Object");
			
			System.out.println("--------------------------");
			
			System.out.println("ID : "+employee.getEmpId());
			System.out.println("Name : "+employee.getEmpName());
			System.out.println("Age : "+employee.getEmpAge());
			System.out.println("Qualification : "+employee.getEmpQualification());
			System.out.println("Salary : "+employee.getEmpSalary());

		} catch (FileNotFoundException e) {

			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}
}
