package com.dineshkrish.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.dineshkrish.dto.UserDetails;
import com.dineshkrish.util.DBUtils;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class UserDetailsDAO {

	public UserDetails validateUser(String userName, String password) {
		
		// getting the connection from DBUtils
		final Connection connection = DBUtils.getConnection(); 
		
		String sql_query = "SELECT USERID, NAME, EMAILID, PHONE FROM USER_DETAILS WHERE USERNAME = ? AND PASSWORD = ?";
		
		UserDetails userDetails = null;
		
		try {
			
			PreparedStatement stmt = connection.prepareStatement(sql_query);
			
			stmt.setString(1, userName);
			stmt.setString(2, password);
			
			// executing the query
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				
				// defining the UserDetails object
				userDetails = new UserDetails();
				
				// setting the all attributes to object from database
				userDetails.setUserId(rs.getInt("userId"));
				userDetails.setUserName(userName);
				userDetails.setName(rs.getString("name"));
				userDetails.setEmailId(rs.getString("emailId"));
				userDetails.setPhone(rs.getString("phone"));
				userDetails.setValidUser(true);
				
			}
			
		} catch(Exception ex) {
			
			System.out.println(ex.getMessage());
		}
		
		return userDetails;
	}
}
