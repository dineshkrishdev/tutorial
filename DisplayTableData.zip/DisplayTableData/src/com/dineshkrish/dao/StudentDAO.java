package com.dineshkrish.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dineshkrish.dto.Student;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class StudentDAO {

	public List<Student> getStudentList() {

		List<Student> studentList = new ArrayList<Student>();

		Connection connection = null;

		try {

			// Loading Driver Class
			Class.forName("com.mysql.jdbc.Driver");

			// Getting the Connection
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "root");

			Statement statement = connection.createStatement();

			ResultSet rs = statement.executeQuery("SELECT * FROM student_details");

			while (rs.next()) {

				// Defining Student Object
				Student student = new Student();

				student.setFirstName(rs.getString("firstName"));
				student.setSecondName(rs.getString("lastName"));
				student.setAge(rs.getInt("age"));
				student.setEmailId(rs.getString("emailId"));
				student.setContactNumber(rs.getString("contactNumber"));
				student.setAddress(rs.getString("address"));

				// Adding the Student Object to List
				studentList.add(student);
			}

			// Closing the Resources
			rs.close();
			statement.close();
			connection.close();

		} catch (SQLException e) {

			System.out.println(e.getMessage());
			e.printStackTrace();
		} catch (ClassNotFoundException e) {

			System.out.println(e.getMessage());
			e.printStackTrace();
		}

		return studentList;
	}
}
