package com.dineshkrish.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dineshkrish.dao.StudentDAO;
import com.dineshkrish.dto.Student;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class DisplayRecordsController extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		StudentDAO dao = new StudentDAO();

		// Getting Student List from Database
		List<Student> studentList = dao.getStudentList();
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("studentList.jsp");

		req.setAttribute("studentList", studentList);
		
		dispatcher.forward(req, resp);
	}

}
