package com.dineshkrish;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {

	private static Connection connection;

	private static final String DRIVER_NAME = "com.mysql.jdbc.Driver";

	// Connection URL 
	private static final String CONNECTION_URL = "jdbc:mysql://localhost:3306/dineshkrish";
	
	// your user name
	private static final String USERNAME = "root";

	// your password
	private static final String PASSWORD = "root";
	
	public static Connection getConnection() {

		try {

			Class.forName(DRIVER_NAME);

			connection = DriverManager.getConnection(CONNECTION_URL, USERNAME, PASSWORD);

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
			
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return connection;
	}
}
