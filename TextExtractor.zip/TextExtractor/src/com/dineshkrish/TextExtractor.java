package com.dineshkrish;

import java.io.File;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

/**
 * 
 * @author Dinesh Krishnan
 *
 */

public class TextExtractor {

	private static ITesseract instance;

	private TextExtractor() {

	}

	public static ITesseract getInstance() {

		if (instance == null) {

			instance = new Tesseract();
		}

		return instance;
	}

	public static String getText(final File imageFile) {

		String result = null;

		try {

			result = TextExtractor.getInstance().doOCR(imageFile);

		} catch (TesseractException e) {

			e.printStackTrace();
		}

		return result;
	}

	public static void main(String[] args) {

		String fileName = "input.png";

		File imageFile = new File(fileName);

		System.out.println("The Text is : " + TextExtractor.getText(imageFile));

	}
}