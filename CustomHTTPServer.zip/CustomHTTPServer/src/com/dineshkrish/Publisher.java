package com.dineshkrish;

public class Publisher {

	public static void main(String[] args) {
		
		MyServer applicationServer = new MyServer(8000);
		
		applicationServer.init();
		
		applicationServer.deployApplication("/welcome", new MyRequestHandler());
		
		applicationServer.start();
	}
}
