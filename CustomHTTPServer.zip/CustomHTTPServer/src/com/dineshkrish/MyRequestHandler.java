package com.dineshkrish;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class MyRequestHandler implements HttpHandler {

	@Override
	public void handle(HttpExchange httpExchange) throws IOException {

		URI requestedURI = httpExchange.getRequestURI();

		if (requestedURI != null) {

			sendResponse(requestedURI, httpExchange);

		}

	}

	private void sendResponse(URI requestedURI, HttpExchange httpExchange) {

		if (requestedURI != null) {

			try {

				String path = String.valueOf(requestedURI);

				String response = "";

				if (path != null && !path.isEmpty()) {

					if ("/welcome".equals(path)) {

						response = getResponse(path);

					} else if ("/welcome/page1".equals(path)) {

						response = getResponse(path);

					} else if ("/welcome/page2".equals(path)) {

						response = getResponse(path);

					} else if ("/welcome/page3".equals(path)) {

						response = getResponse(path);

					} else {
						response = "<h1>Oops!!! Page not found...</h1>";
					}
				}

				httpExchange.sendResponseHeaders(200, response.length());
				OutputStream os = httpExchange.getResponseBody();
				os.write(response.getBytes());
				os.close();

			} catch (IOException e) {

				System.out.println(e.getMessage());
				e.printStackTrace();
			}

		}
	}

	private String getResponse(String requestURL) {

		String fileName = requestMapping().get(requestURL);

		File file = new File(fileName);
		String content = "";

		try {

			byte[] b = Files.readAllBytes(file.toPath());

			content = new String(b);

		} catch (IOException e) {

			e.printStackTrace();
		}

		return content;
	}

	private Map<String, String> requestMapping() {

		Map<String, String> map = new HashMap<String, String>();

		map.put("/welcome", "pages/welcome.html");
		map.put("/welcome/page1", "pages/page1.html");
		map.put("/welcome/page2", "pages/page2.html");
		map.put("/welcome/page3", "pages/page3.html");

		return map;
	}

}
