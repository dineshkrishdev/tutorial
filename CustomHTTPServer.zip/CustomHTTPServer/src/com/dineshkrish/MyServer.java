package com.dineshkrish;

import java.io.IOException;
import java.net.InetSocketAddress;

import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

public class MyServer {

	private int port;

	private HttpServer server = null;
	
	public MyServer(int port) {
		
		this.port = port;
	}

	// Method to initialize the server
	public void init() {
		
		try {
			
			InetSocketAddress address = new InetSocketAddress(port);
			
			server = HttpServer.create(address, 0);
			
		} catch (IOException e) {
			
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	// Method to deploying the application
	public void deployApplication(String contextPath, HttpHandler handler) {

		if ((contextPath != null && !contextPath.isEmpty()) && handler != null) {
			server.createContext(contextPath, handler);
		} else {
			
			System.out.println("Invalid Information Provided");
		}
	}
	
	// Method to start the server
	public void start() {
		
		server.start();
		System.out.println("Server is running....");
	}

}
